# Changelog

## 1.0.0 (unreleased)
- Initial source release: side player preview, tilted floating panel, open/close animations, settings.
