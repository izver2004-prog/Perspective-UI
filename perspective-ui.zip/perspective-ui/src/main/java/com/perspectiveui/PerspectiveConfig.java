package com.perspectiveui;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Persistent settings, stored as config/perspective-ui.json. */
public final class PerspectiveConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("perspective-ui.json");
    private static PerspectiveConfig instance = new PerspectiveConfig();

    public boolean enabled = true;
    public boolean inventoryEnabled = true;
    public boolean containersEnabled = true;
    /** Show the REAL player standing in the world (third-person camera shifted sideways). */
    public boolean worldPlayer = true;
    /** Fallback: draw a GUI model of the player at the left (only used when worldPlayer is off). */
    public boolean playerPreview = true;
    /** Vanilla dim/blur behind container screens. Off = world stays bright and visible. */
    public boolean dimBackground = false;
    /** Put the player on the right side instead of the left (if the camera side feels mirrored). */
    public boolean flipCameraSide = false;
    public boolean mouseFollow = true;
    public boolean closeAnimation = true;
    /** 0..100 */
    public int intensity = 60;
    /** Panel size in percent, 90..150 */
    public int uiScale = 115;
    /** 25..300 (percent) */
    public int animationSpeed = 100;

    public static PerspectiveConfig get() {
        return instance;
    }

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                PerspectiveConfig c = GSON.fromJson(Files.readString(FILE), PerspectiveConfig.class);
                if (c != null) instance = c;
            }
        } catch (Exception e) {
            PerspectiveUiClient.LOGGER.warn("Could not read config, using defaults", e);
        }
        instance.clamp();
        save();
    }

    public static void save() {
        try {
            instance.clamp();
            Files.writeString(FILE, GSON.toJson(instance));
        } catch (IOException e) {
            PerspectiveUiClient.LOGGER.warn("Could not save config", e);
        }
    }

    public static void reset() {
        instance = new PerspectiveConfig();
        save();
    }

    private void clamp() {
        intensity = Math.max(0, Math.min(100, intensity));
        animationSpeed = Math.max(25, Math.min(300, animationSpeed));
        uiScale = Math.max(90, Math.min(150, uiScale));
    }
}
