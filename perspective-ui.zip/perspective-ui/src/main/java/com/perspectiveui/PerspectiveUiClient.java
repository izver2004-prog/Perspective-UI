package com.perspectiveui;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

public final class PerspectiveUiClient implements ClientModInitializer {
    public static final String MOD_ID = "perspectiveui";
    public static final Logger LOGGER = LoggerFactory.getLogger("PerspectiveUI");

    private static final String PKG = "net.minecraft.client.gui.screens.inventory.";
    private static final String INVENTORY = PKG + "InventoryScreen";
    /** Allowlist by class name; anything else (incl. creative inventory) keeps the vanilla look. */
    private static final Set<String> SUPPORTED = Set.of(
            INVENTORY, PKG + "CraftingScreen", PKG + "ContainerScreen", PKG + "ShulkerBoxScreen",
            PKG + "HopperScreen", PKG + "DispenserScreen", PKG + "AbstractFurnaceScreen",
            PKG + "AnvilScreen", PKG + "EnchantmentScreen", PKG + "BrewingStandScreen",
            PKG + "GrindstoneScreen", PKG + "SmithingScreen", PKG + "CartographyTableScreen",
            PKG + "StonecutterScreen", PKG + "LoomScreen", PKG + "MerchantScreen",
            PKG + "BeaconScreen", PKG + "CrafterScreen", PKG + "HorseInventoryScreen");

    private static final Map<Screen, PerspectiveAnimator> ANIMATORS =
            Collections.synchronizedMap(new WeakHashMap<>());
    /** Re-entrancy guard shared by all input mixins (mixin statics would be per-target-class). */
    public static boolean inputNested;
    private static volatile boolean openConfig;

    @Override
    public void onInitializeClient() {
        PerspectiveConfig.load();

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (openConfig) {
                openConfig = false;
                mc.setScreen(new PerspectiveConfigScreen(mc.screen));
                return;
            }
            Screen s = mc.screen;
            if (s == null || !ANIMATORS.containsKey(s)) CameraControl.release(mc);
            PerspectiveAnimator a = s == null ? null : ANIMATORS.get(s);
            if (a != null && a.closeFinished()) {
                a.bypassClose = true;
                s.onClose(); // runs the real vanilla close now that the animation is done
            }
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, buildContext) ->
                dispatcher.register(ClientCommands.literal("perspectiveui")
                        .executes(ctx -> { openConfig = true; return 1; })
                        .then(ClientCommands.literal("reset").executes(ctx -> {
                            PerspectiveConfig.reset();
                            ctx.getSource().sendFeedback(Component.literal("Perspective UI: defaults restored"));
                            return 1;
                        }))
                        .then(ClientCommands.literal("intensity")
                                .then(ClientCommands.argument("percent", IntegerArgumentType.integer(0, 100))
                                        .executes(ctx -> {
                                            PerspectiveConfig.get().intensity = IntegerArgumentType.getInteger(ctx, "percent");
                                            PerspectiveConfig.save();
                                            return 1;
                                        })))));
    }

    private static boolean supported(Screen s) {
        if (!(s instanceof AbstractContainerScreen<?>)) return false;
        PerspectiveConfig c = PerspectiveConfig.get();
        if (!c.enabled) return false;
        boolean inventory = false, ok = false;
        for (Class<?> k = s.getClass(); k != null; k = k.getSuperclass()) {
            if (SUPPORTED.contains(k.getName())) {
                ok = true;
                if (k.getName().equals(INVENTORY)) inventory = true;
            }
        }
        return ok && (inventory ? c.inventoryEnabled : c.containersEnabled);
    }

    /** Animator for a supported screen (created on first render), or null for vanilla behavior. */
    public static PerspectiveAnimator animatorFor(Screen s) {
        return supported(s) ? ANIMATORS.computeIfAbsent(s, k -> new PerspectiveAnimator()) : null;
    }

    /** Existing animator that has already rendered at least one transformed frame, else null. */
    public static PerspectiveAnimator active(Screen s) {
        PerspectiveAnimator a = ANIMATORS.get(s);
        return a != null && a.hasTransform() && supported(s) ? a : null;
    }
}
