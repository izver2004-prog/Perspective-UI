package com.perspectiveui;

import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.world.entity.LivingEntity;

/**
 * Puts the real player "into the scene" while a container screen is open: switches to the
 * third-person camera and (via CameraMixin) moves it closer and sideways so the player stands
 * at the left of the screen. The offset is blended with the screen animation, and the previous
 * camera type is always restored.
 */
public final class CameraControl {
    public static final float DISTANCE = 2.6f;
    public static final float SIDE = 1.9f;

    private static boolean engaged;
    private static CameraType saved;
    private static float value, target;
    private static float headYaw, headPitch; // smoothed cursor direction, -1..1
    private static long last = System.nanoTime();

    /** Called every frame by the renderer: t = 0..1 desired blend. */
    public static void set(Minecraft mc, float t, float hx, float hy) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1_000_000_000f);
        last = now;
        target = t;
        if (!engaged && t > 0f) {
            saved = mc.options.getCameraType();
            mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);
            engaged = true;
            value = 0f;
        }
        if (engaged) {
            value += (target - value) * (1f - (float) Math.exp(-dt * 14f));
            float k = 1f - (float) Math.exp(-dt * 10f);
            headYaw += (hx - headYaw) * k;
            headPitch += (hy - headPitch) * k;
            if (target <= 0f && value < 0.02f) release(mc);
        }
    }

    public static void release(Minecraft mc) {
        if (!engaged) return;
        engaged = false;
        value = 0f;
        target = 0f;
        if (saved != null) mc.options.setCameraType(saved);
    }

    /**
     * Render-state only (no entity/network changes): turn the body toward the menu and let the
     * head follow the cursor. Called from LivingEntityRendererMixin for the local player.
     */
    public static void applyPose(LivingEntity entity, LivingEntityRenderState state) {
        if (!engaged || value < 0.01f) return;
        if (entity != Minecraft.getInstance().player) return;
        float dir = PerspectiveConfig.get().flipCameraSide ? -1f : 1f;
        float turn = 32f * dir * value;
        state.bodyRot += turn;
        float head = state.yRot + headYaw * 55f * value - turn;
        state.yRot = Math.max(-75f, Math.min(75f, head));
        state.xRot = state.xRot * (1f - value) + headPitch * 30f * value;
    }

    public static float value() { return engaged ? value : 0f; }
    public static float side() { return PerspectiveConfig.get().flipCameraSide ? -SIDE : SIDE; }

    private CameraControl() {}
}
