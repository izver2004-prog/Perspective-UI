package com.perspectiveui;

import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;

/**
 * Puts the real player "into the scene" while a container screen is open: switches to the
 * third-person camera and (via CameraMixin) moves it closer and sideways so the player stands
 * at the left of the screen. The offset is blended with the screen animation, and the previous
 * camera type is always restored.
 */
public final class CameraControl {
    public static final float DISTANCE = 2.6f;
    public static final float SIDE = 1.9f;

    private static boolean engaged;
    private static CameraType saved;
    private static float value, target;
    private static long last = System.nanoTime();

    /** Called every frame by the renderer: t = 0..1 desired blend. */
    public static void set(Minecraft mc, float t) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1_000_000_000f);
        last = now;
        target = t;
        if (!engaged && t > 0f) {
            saved = mc.options.getCameraType();
            mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);
            engaged = true;
            value = 0f;
        }
        if (engaged) {
            value += (target - value) * (1f - (float) Math.exp(-dt * 14f));
            if (target <= 0f && value < 0.02f) release(mc);
        }
    }

    public static void release(Minecraft mc) {
        if (!engaged) return;
        engaged = false;
        value = 0f;
        target = 0f;
        if (saved != null) mc.options.setCameraType(saved);
    }

    public static float value() { return engaged ? value : 0f; }
    public static float side() { return PerspectiveConfig.get().flipCameraSide ? -SIDE : SIDE; }

    private CameraControl() {}
}
