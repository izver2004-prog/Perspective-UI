package com.perspectiveui;

import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;

/**
 * Puts the real player "into the scene" while a container screen is open: switches to the
 * third-person camera and (via CameraMixin) places it at a FIXED offset (distance, side) from the
 * player, ignoring wall collision, so the framing never changes while the player moves.
 * The pose of the player (body turn, head following the cursor, no walk animation) is applied to
 * the render state only, in absolute terms relative to the camera yaw, so walking does not turn
 * or sway the model. The previous camera type is always restored.
 */
public final class CameraControl {
    public static final float DISTANCE = 1.9f;
    public static final float SIDE = 1.4f;
    private static final float BODY_TURN = 32f, HEAD_YAW = 28f, HEAD_PITCH = 14f;

    private static boolean engaged;
    private static CameraType saved;
    private static float value, target;
    private static float headYaw, headPitch; // smoothed cursor direction, -1..1
    private static long last = System.nanoTime();

    /** Called every frame by the renderer: t = 0..1 desired blend, hx/hy = cursor direction. */
    public static void set(Minecraft mc, float t, float hx, float hy) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1_000_000_000f);
        last = now;
        target = t;
        if (!engaged && t > 0f) {
            saved = mc.options.getCameraType();
            mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);
            engaged = true;
            value = 0f;
            headYaw = 0f;
            headPitch = 0f;
        }
        if (engaged) {
            value += (target - value) * (1f - (float) Math.exp(-dt * 10f));
            float k = 1f - (float) Math.exp(-dt * 6f);
            headYaw += (hx - headYaw) * k;
            headPitch += (hy - headPitch) * k;
            if (target <= 0f && value < 0.02f) release(mc);
        }
    }

    public static void release(Minecraft mc) {
        if (!engaged) return;
        engaged = false;
        value = 0f;
        target = 0f;
        if (saved != null) mc.options.setCameraType(saved);
    }

    /**
     * Render-state only (no entity/network changes). Absolute pose relative to the view yaw:
     * body turned toward the menu, head toward the cursor, legs/arms not swinging.
     */
    public static void applyPose(LivingEntity entity, LivingEntityRenderState state, float partialTick) {
        if (!engaged || value < 0.01f) return;
        if (entity != Minecraft.getInstance().player) return;
        float dir = PerspectiveConfig.get().flipCameraSide ? -1f : 1f;
        float viewYaw = entity.getViewYRot(partialTick);

        float body0 = state.bodyRot;
        float head0 = body0 + state.yRot;
        float bodyTarget = viewYaw + BODY_TURN * dir;
        float headTarget = viewYaw + headYaw * HEAD_YAW;

        float body1 = body0 + Mth.wrapDegrees(bodyTarget - body0) * value;
        float head1 = head0 + Mth.wrapDegrees(headTarget - head0) * value;
        state.bodyRot = body1;
        state.yRot = Math.max(-75f, Math.min(75f, Mth.wrapDegrees(head1 - body1)));
        state.xRot = state.xRot * (1f - value) + headPitch * HEAD_PITCH * value;
        state.walkAnimationSpeed *= (1f - value);
    }

    public static float value() { return engaged ? value : 0f; }
    public static float side() { return PerspectiveConfig.get().flipCameraSide ? -SIDE : SIDE; }

    private CameraControl() {}
}
