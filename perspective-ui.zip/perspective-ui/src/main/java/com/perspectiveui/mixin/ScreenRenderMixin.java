package com.perspectiveui.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.perspectiveui.PerspectiveAnimator;
import com.perspectiveui.PerspectiveRenderer;
import com.perspectiveui.PerspectiveUiClient;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;

/**
 * Wraps the OUTERMOST screen render entry point (so recipe book, tooltips and subclass drawing
 * all share one transform). Uses MixinExtras @WrapMethod instead of HEAD/RETURN injects, which
 * keeps it compatible with other GUI mods. require = 0: if the method name differs, the mod
 * degrades to vanilla visuals instead of crashing (input is only remapped after a transformed frame).
 * VERIFY: method name in 26.1.2 (expected: extractRenderStateWithTooltipAndSubtitles).
 */
@Mixin(Screen.class)
public abstract class ScreenRenderMixin {

    @WrapMethod(method = "extractRenderStateWithTooltipAndSubtitles", require = 0)
    private void pui$render(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick,
                            Operation<Void> original) {
        PerspectiveAnimator anim = PerspectiveUiClient.animatorFor((Screen) (Object) this);
        if (anim == null) {
            original.call(graphics, mouseX, mouseY, partialTick);
            return;
        }
        PerspectiveRenderer.render((Screen) (Object) this, anim, graphics, mouseX, mouseY,
                (g, mx, my) -> original.call(g, mx, my, partialTick));
    }

    /**
     * The dim/blur background must cover the whole window, so it is drawn with an identity pose
     * while the panel transform is active. VERIFY: method name (expected: extractBackground).
     */
    @WrapMethod(method = "extractBackground", require = 0)
    private void pui$background(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick,
                                Operation<Void> original) {
        if (!PerspectiveRenderer.isTransforming()) {
            original.call(graphics, mouseX, mouseY, partialTick);
            return;
        }
        if (!com.perspectiveui.PerspectiveConfig.get().dimBackground) return; // keep the world bright and visible
        graphics.pose().pushMatrix();
        graphics.pose().identity();
        try {
            original.call(graphics, mouseX, mouseY, partialTick);
        } finally {
            graphics.pose().popMatrix();
        }
    }
}
