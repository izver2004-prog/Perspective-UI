package com.perspectiveui.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.perspectiveui.CameraControl;
import net.minecraft.client.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * Third-person camera placement: wraps the call that moves the camera back from the player's head
 * and makes the distance shorter and adds a sideways offset, blended by CameraControl.value().
 * Only active while a Perspective UI screen is open; otherwise the original call is untouched.
 * The method is selected by regex (name differs between versions: setup / alignWithEntity / ...);
 * require = 0 so a mismatch only means "camera is not shifted", never a crash.
 * VERIFY: Camera#move(float, float, float) = (backwards distance, up, sideways right).
 */
@Mixin(Camera.class)
public abstract class CameraMixin {

    @WrapOperation(method = "/.*/",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Camera;move(FFF)V"),
            require = 0)
    private void pui$move(Camera self, float z, float y, float x, Operation<Void> original) {
        float p = CameraControl.value();
        if (p <= 0.001f) {
            original.call(self, z, y, x);
            return;
        }
        // Fixed framing: distance/side do not depend on wall collision or movement.
        original.call(self, -CameraControl.DISTANCE * p, y, x + CameraControl.side() * p);
    }
}
