package com.perspectiveui.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.perspectiveui.PerspectiveAnimator;
import com.perspectiveui.PerspectiveConfig;
import com.perspectiveui.PerspectiveUiClient;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import org.spongepowered.asm.mixin.Mixin;

/**
 * Maps real mouse coordinates into the transformed panel space with the exact inverse of the
 * rendered matrix, so slots, drag & drop, scrolling and widgets hit what the player sees.
 *
 * Targets every class in the container-screen hierarchy that overrides mouse handling (string
 * targets: classes missing in a given version are simply ignored). A re-entrancy guard makes sure
 * the mapping is applied once per event even though subclasses call super.
 * Also delays onClose() so the closing animation can play (the vanilla close runs afterwards).
 */
@Mixin(targets = {
        "net.minecraft.client.gui.screens.inventory.AbstractContainerScreen",
        "net.minecraft.client.gui.screens.inventory.AbstractRecipeBookScreen",
        "net.minecraft.client.gui.screens.inventory.EnchantmentScreen",
        "net.minecraft.client.gui.screens.inventory.MerchantScreen",
        "net.minecraft.client.gui.screens.inventory.StonecutterScreen",
        "net.minecraft.client.gui.screens.inventory.LoomScreen"
})
public abstract class ContainerInputMixin {
    @WrapMethod(method = "mouseClicked", require = 0)
    private boolean pui$click(MouseButtonEvent event, boolean doubleClick, Operation<Boolean> original) {
        PerspectiveAnimator a = pui$anim();
        if (a == null || PerspectiveUiClient.inputNested) return original.call(event, doubleClick);
        if (a.closing) return true;
        PerspectiveUiClient.inputNested = true;
        try { return original.call(a.map(event), doubleClick); } finally { PerspectiveUiClient.inputNested = false; }
    }

    @WrapMethod(method = "mouseReleased", require = 0)
    private boolean pui$release(MouseButtonEvent event, Operation<Boolean> original) {
        PerspectiveAnimator a = pui$anim();
        if (a == null || PerspectiveUiClient.inputNested) return original.call(event);
        PerspectiveUiClient.inputNested = true;
        try { return original.call(a.map(event)); } finally { PerspectiveUiClient.inputNested = false; }
    }

    @WrapMethod(method = "mouseDragged", require = 0)
    private boolean pui$drag(MouseButtonEvent event, double dx, double dy, Operation<Boolean> original) {
        PerspectiveAnimator a = pui$anim();
        if (a == null || PerspectiveUiClient.inputNested) return original.call(event, dx, dy);
        double[] d = a.mapDelta(event.x(), event.y(), dx, dy);
        PerspectiveUiClient.inputNested = true;
        try { return original.call(a.map(event), d[0], d[1]); } finally { PerspectiveUiClient.inputNested = false; }
    }

    @WrapMethod(method = "mouseScrolled", require = 0)
    private boolean pui$scroll(double x, double y, double scrollX, double scrollY, Operation<Boolean> original) {
        PerspectiveAnimator a = pui$anim();
        if (a == null || PerspectiveUiClient.inputNested) return original.call(x, y, scrollX, scrollY);
        var p = a.toLocal(x, y);
        PerspectiveUiClient.inputNested = true;
        try { return original.call((double) p.x, (double) p.y, scrollX, scrollY); } finally { PerspectiveUiClient.inputNested = false; }
    }

    @WrapMethod(method = "onClose", require = 0)
    private void pui$close(Operation<Void> original) {
        PerspectiveAnimator a = pui$anim();
        if (a != null && PerspectiveConfig.get().closeAnimation && !a.closing && !a.bypassClose) {
            a.closing = true; // vanilla close is performed from the client tick once the animation ends
            return;
        }
        original.call();
    }

    private PerspectiveAnimator pui$anim() {
        return PerspectiveUiClient.active((Screen) (Object) this);
    }
}
