package com.perspectiveui.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.perspectiveui.PerspectiveRenderer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;

/**
 * Hides vanilla's small in-panel player while our large side preview is shown, to avoid a duplicate.
 * Our own preview is drawn after the panel transform is popped, so it is not affected.
 * VERIFY: method name/signature (expected: static extractEntityInInventoryFollowsMouse, 10 params).
 */
@Mixin(InventoryScreen.class)
public abstract class InventoryScreenMixin {

    @WrapMethod(method = "extractEntityInInventoryFollowsMouse", require = 0)
    private static void pui$hideVanilla(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int scale,
                                        float yOffset, float mouseX, float mouseY, LivingEntity entity,
                                        Operation<Void> original) {
        if (PerspectiveRenderer.hidesVanillaPreview()) return;
        original.call(g, x1, y1, x2, y2, scale, yOffset, mouseX, mouseY, entity);
    }
}
