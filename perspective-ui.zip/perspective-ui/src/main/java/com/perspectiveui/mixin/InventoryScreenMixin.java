package com.perspectiveui.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.perspectiveui.PerspectiveRenderer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.entity.LivingEntity;
import org.joml.Matrix3x2f;
import org.joml.Vector2f;
import org.spongepowered.asm.mixin.Mixin;

/**
 * The small player in the black inventory window is drawn by a separate GUI-entity pass that
 * ignores the pose matrix. While our transform is active we map its box, scale and mouse position
 * through the same matrix and draw it with an identity pose, so it stays inside the (tilted)
 * black window and keeps looking at the cursor like in vanilla. Creative inventory uses the same call.
 * VERIFY: method name/signature (expected: static extractEntityInInventoryFollowsMouse, 10 params).
 */
@Mixin(InventoryScreen.class)
public abstract class InventoryScreenMixin {

    @WrapMethod(method = "extractEntityInInventoryFollowsMouse", require = 0)
    private static void pui$mapPreview(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int scale,
                                       float yOffset, float mouseX, float mouseY, LivingEntity entity,
                                       Operation<Void> original) {
        if (!PerspectiveRenderer.isTransforming()) {
            original.call(g, x1, y1, x2, y2, scale, yOffset, mouseX, mouseY, entity);
            return;
        }
        Matrix3x2f m = PerspectiveRenderer.currentMatrix();
        Vector2f a = m.transformPosition(x1, y1, new Vector2f());
        Vector2f b = m.transformPosition(x2, y2, new Vector2f());
        Vector2f p = m.transformPosition(mouseX, mouseY, new Vector2f());
        int sc = Math.max(1, Math.round(scale * PerspectiveRenderer.uniformScale()));
        g.pose().pushMatrix();
        g.pose().identity();
        try {
            original.call(g, Math.round(a.x), Math.round(a.y), Math.round(b.x), Math.round(b.y),
                    sc, yOffset, p.x, p.y, entity);
        } finally {
            g.pose().popMatrix();
        }
    }
}
