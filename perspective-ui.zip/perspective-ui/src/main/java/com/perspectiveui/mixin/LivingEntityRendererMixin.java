package com.perspectiveui.mixin;

import com.perspectiveui.CameraControl;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Edits only the render STATE of the local player (body turn toward the menu, head following the
 * cursor) while a Perspective UI screen is open. The real entity, its rotation and networking are
 * untouched. require = 0: if the signature differs, the player simply is not posed.
 * VERIFY: LivingEntityRenderer#extractRenderState(LivingEntity, LivingEntityRenderState, float).
 */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {

    @Inject(method = "extractRenderState(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;F)V",
            at = @At("TAIL"), require = 0)
    private void pui$pose(LivingEntity entity, LivingEntityRenderState state, float partialTick, CallbackInfo ci) {
        CameraControl.applyPose(entity, state, partialTick);
    }
}
