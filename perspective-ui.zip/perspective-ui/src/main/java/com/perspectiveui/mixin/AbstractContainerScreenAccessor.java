package com.perspectiveui.mixin;

import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Read-only access to the panel rectangle. Plain accessor, no behavior change. */
@Mixin(AbstractContainerScreen.class)
public interface AbstractContainerScreenAccessor {
    @Accessor("leftPos") int pui$leftPos();
    @Accessor("topPos") int pui$topPos();
    @Accessor("imageWidth") int pui$imageWidth();
    @Accessor("imageHeight") int pui$imageHeight();
}
