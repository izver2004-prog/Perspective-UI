package com.perspectiveui;

import net.minecraft.client.input.MouseButtonEvent;
import org.joml.Matrix3x2f;
import org.joml.Vector2f;

/**
 * Per-screen animation state. All motion is integrated with real frame time (not FPS).
 * Also remembers the last transform that was actually rendered, so that input can be
 * mapped back with its exact inverse (visual area == click area).
 */
public final class PerspectiveAnimator {
    private static final float OPEN_SECONDS = 0.36f;

    public boolean closing;
    public boolean bypassClose;

    private boolean first = true;
    private long last = System.nanoTime();
    private float progress;       // 0..1 linear
    private float mx, my;         // smoothed pointer, -1..1
    private float shift;          // smoothed layout shift in GUI px
    private float slide;          // decaying offset that hides sudden layout jumps (recipe book)
    private float lastLeft;
    private boolean hasLeft;
    private Matrix3x2f inverse;   // inverse of the last rendered transform

    public void update(float targetX, float targetY, float targetShift, float left, PerspectiveConfig c) {
        long now = System.nanoTime();
        float dt = first ? 1f / 60f : Math.min(0.1f, (now - last) / 1_000_000_000f);
        first = false;
        last = now;
        float speed = Math.max(0.1f, c.animationSpeed / 100f);
        progress = clamp(progress + (closing ? -1f : 1f) * dt * speed / OPEN_SECONDS);

        float kp = 1f - (float) Math.exp(-dt * 6f * speed);
        mx += ((c.mouseFollow ? targetX : 0f) - mx) * kp;
        my += ((c.mouseFollow ? targetY : 0f) - my) * kp;

        float ks = 1f - (float) Math.exp(-dt * 8f * speed);
        shift += (targetShift - shift) * ks;

        // When the recipe book opens/closes vanilla moves the panel instantly. Keep the old
        // visual position and let the offset decay, so the panel glides to its new place.
        if (hasLeft && Math.abs(left - lastLeft) > 0.5f) slide += lastLeft - left;
        lastLeft = left;
        hasLeft = true;
        slide -= slide * ks;
    }

    /** Smootherstep-eased visibility 0..1 (zero slope at both ends). */
    public float eased() {
        float p = progress;
        return p * p * p * (p * (p * 6f - 15f) + 10f);
    }
    public float pointerX() { return mx; }
    public float pointerY() { return my; }
    public float shift() { return shift; }
    public float slide() { return slide; }
    public boolean closeFinished() { return closing && progress <= 0f; }
    public boolean hasTransform() { return inverse != null; }

    public void setTransform(Matrix3x2f m) {
        inverse = new Matrix3x2f(m).invert();
    }

    public Vector2f toLocal(double x, double y) {
        Vector2f out = new Vector2f((float) x, (float) y);
        if (inverse != null) inverse.transformPosition((float) x, (float) y, out);
        return out;
    }

    public MouseButtonEvent map(MouseButtonEvent e) {
        if (inverse == null) return e;
        Vector2f p = toLocal(e.x(), e.y());
        return new MouseButtonEvent(p.x, p.y, e.buttonInfo());
    }

    /** Maps a drag delta by differencing two mapped points. */
    public double[] mapDelta(double x, double y, double dx, double dy) {
        Vector2f a = toLocal(x, y);
        Vector2f b = toLocal(x - dx, y - dy);
        return new double[]{a.x - b.x, a.y - b.y};
    }

    private static float clamp(float v) { return v < 0f ? 0f : Math.min(v, 1f); }
}
