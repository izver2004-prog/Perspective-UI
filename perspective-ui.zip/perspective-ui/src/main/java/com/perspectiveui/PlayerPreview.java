package com.perspectiveui;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.entity.LivingEntity;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * Draws the real player (skin, armor, held items) with vanilla's own in-GUI entity renderer,
 * so no custom rendering code, GL calls or extra entity is involved. The vanilla method is
 * located by name pattern once, so a small rename between 26.1.x patches does not break compilation.
 */
final class PlayerPreview {
    private static MethodHandle handle;
    private static boolean searched, failed;

    static void draw(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int scale,
                     float pointerX, float pointerY, LivingEntity entity) {
        if (failed) return;
        try {
            if (!searched) find();
            if (handle == null) return;
            handle.invoke(g, x1, y1, x2, y2, scale, 0.0625f, pointerX, pointerY, entity);
        } catch (Throwable t) {
            failed = true;
            PerspectiveUiClient.LOGGER.error("Player preview disabled: vanilla entity renderer signature differs", t);
        }
    }

    private static void find() throws IllegalAccessException {
        searched = true;
        for (Method m : InventoryScreen.class.getDeclaredMethods()) {
            if (Modifier.isStatic(m.getModifiers()) && m.getName().endsWith("EntityInInventoryFollowsMouse")
                    && m.getParameterCount() == 10) {
                m.setAccessible(true);
                handle = MethodHandles.lookup().unreflect(m);
                return;
            }
        }
        failed = true;
        PerspectiveUiClient.LOGGER.error("Player preview disabled: vanilla *EntityInInventoryFollowsMouse not found");
    }

    private PlayerPreview() {}
}
