package com.perspectiveui;

import com.perspectiveui.mixin.AbstractContainerScreenAccessor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import org.joml.Matrix3x2f;
import org.joml.Vector2f;

/**
 * Builds the panel transform and renders a container screen through it.
 *
 * The 26.1 GUI pose is a 2D affine Matrix3x2fStack, so a true projective transform is not
 * possible without a custom render target/shader (which would conflict with Sodium/VulkanMod
 * and other GUI mods). We approximate perspective with: horizontal squeeze (yaw), vertical
 * squeeze (pitch), shear, parallax and scale. Input uses the exact inverse of this matrix.
 */
public final class PerspectiveRenderer {
    @FunctionalInterface
    public interface Draw { void draw(GuiGraphicsExtractor g, int mouseX, int mouseY); }

    private static boolean transforming;
    private static Matrix3x2f current = new Matrix3x2f();

    /** Matrix of the frame being drawn (valid while isTransforming()). */
    public static Matrix3x2f currentMatrix() { return current; }
    /** Uniform scale factor of the current matrix. */
    public static float uniformScale() { return (float) Math.sqrt(Math.abs(current.determinant())); }

    public static boolean isTransforming() { return transforming; }

    public static void render(Screen s, PerspectiveAnimator a, GuiGraphicsExtractor g,
                              int mouseX, int mouseY, Draw draw) {
        PerspectiveConfig c = PerspectiveConfig.get();
        AbstractContainerScreenAccessor acc = (AbstractContainerScreenAccessor) s;
        float w = s.width, h = s.height;
        float pw = acc.pui$imageWidth(), ph = acc.pui$imageHeight();
        float cx = acc.pui$leftPos() + pw / 2f, cy = acc.pui$topPos() + ph / 2f;

        // Layout: if something else moved the panel (e.g. recipe book), stay out of the way.
        boolean layoutModified = Math.abs(acc.pui$leftPos() - (w - pw) / 2f) > 1.5f;
        float targetCx = Math.min(w * 0.66f, w - 8f - pw * 0.48f);
        float rawShift = Math.max(0f, targetCx - cx);
        float leftEdge = cx + rawShift - pw * 0.48f;
        boolean sidePanel = !layoutModified && leftEdge >= 70f && Minecraft.getInstance().player != null;
        boolean worldMode = c.worldPlayer && sidePanel;
        boolean preview = c.playerPreview && !c.worldPlayer && sidePanel; // GUI model fallback
        float targetShift = (worldMode || preview) ? rawShift : 0f;

        float nx = (mouseX / Math.max(1f, w) - 0.5f) * 2f;
        float ny = (mouseY / Math.max(1f, h) - 0.5f) * 2f;
        a.update(nx, ny, targetShift, c);

        float e = a.eased();
        float i = c.intensity / 100f;
        float yaw = (0.20f + 0.10f * a.pointerX()) * i;
        float pitch = 0.06f * a.pointerY() * i;
        float sx = (float) Math.cos(yaw), sy = (float) Math.cos(pitch);
        float ky = -0.06f * i * (1f + 0.5f * a.pointerX());
        float kx = 0.04f * i * a.pointerY();
        float scale = 0.90f + 0.10f * e;
        float dx = a.shift() * e + 5f * i * a.pointerX();
        float dy = 4f * i * a.pointerY() + (1f - e) * 14f;

        Matrix3x2f m = new Matrix3x2f()
                .translate(cx + dx, cy + dy)
                .mul(new Matrix3x2f(1f, ky, kx, 1f, 0f, 0f))
                .scale(sx * scale, sy * scale)
                .translate(-cx, -cy);
        a.setTransform(m);
        float charX = c.flipCameraSide ? w * 0.8f : w * 0.2f;
        float hx = c.mouseFollow ? Math.max(-1f, Math.min(1f, (mouseX - charX) / (w * 0.6f))) : 0f;
        float hy = c.mouseFollow ? Math.max(-1f, Math.min(1f, (mouseY - h * 0.38f) / (h * 0.5f))) : 0f;
        CameraControl.set(Minecraft.getInstance(), worldMode ? e : 0f, hx, hy);

        Vector2f local = a.toLocal(mouseX, mouseY);
        transforming = true;
        current = new Matrix3x2f(m);
        g.pose().pushMatrix();
        g.pose().mul(m);
        try {
            draw.draw(g, Math.round(local.x), Math.round(local.y));
        } finally {
            g.pose().popMatrix();
            transforming = false;
        }

        if (preview && e > 0.02f) {
            float edge = cx + a.shift() * e - pw * 0.48f;
            float charCx = edge / 2f - (1f - e) * 40f;
            float charCy = h * 0.5f;
            int sc = Math.round(Math.min(h * 0.30f, edge * 0.42f));
            if (sc >= 20) {
                // Vanilla rotates the model toward the "mouse"; a constant offset turns it sideways
                // toward the menu, and the smoothed pointer adds a gentle reaction.
                float px = charCx + 120f + (c.mouseFollow ? a.pointerX() * 40f : 0f);
                float py = charCy + (c.mouseFollow ? a.pointerY() * 40f : 0f);
                PlayerPreview.draw(g,
                        Math.round(charCx - sc * 1.3f), Math.round(charCy - sc * 1.45f),
                        Math.round(charCx + sc * 1.3f), Math.round(charCy + sc * 1.45f),
                        sc, px, py, Minecraft.getInstance().player);
            }
        }
    }

    private PerspectiveRenderer() {}
}
