package com.perspectiveui;

import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.IntConsumer;

/** Minimal settings screen (open with /perspectiveui). Saved when the screen is removed. */
public final class PerspectiveConfigScreen extends Screen {
    private final Screen parent;

    public PerspectiveConfigScreen(Screen parent) {
        super(Component.literal("Perspective UI"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        PerspectiveConfig c = PerspectiveConfig.get();
        int left = this.width / 2 - 155, right = this.width / 2 + 5, bw = 150, y0 = 44, step = 24;

        int tw = this.font.width(this.title);
        addRenderableWidget(new StringWidget((this.width - tw) / 2, 18, tw, 12, this.title, this.font));

        addRenderableWidget(toggle(left, y0, bw, "Effects", c.enabled, v -> c.enabled = v));
        addRenderableWidget(toggle(left, y0 + step, bw, "Player inventory", c.inventoryEnabled, v -> c.inventoryEnabled = v));
        addRenderableWidget(toggle(left, y0 + step * 2, bw, "Containers", c.containersEnabled, v -> c.containersEnabled = v));
        addRenderableWidget(toggle(left, y0 + step * 3, bw, "Player in world", c.worldPlayer, v -> c.worldPlayer = v));
        addRenderableWidget(toggle(left, y0 + step * 4, bw, "Dim background", c.dimBackground, v -> c.dimBackground = v));
        addRenderableWidget(toggle(right, y0, bw, "Mouse follow", c.mouseFollow, v -> c.mouseFollow = v));
        addRenderableWidget(toggle(right, y0 + step, bw, "Close animation", c.closeAnimation, v -> c.closeAnimation = v));
        addRenderableWidget(new Slider(right, y0 + step * 2, bw, 20, "Intensity", "%", 0, 100, c.intensity, v -> c.intensity = v));
        addRenderableWidget(new Slider(right, y0 + step * 3, bw, 20, "Anim speed", "%", 25, 300, c.animationSpeed, v -> c.animationSpeed = v));
        addRenderableWidget(toggle(right, y0 + step * 4, bw, "GUI player (fallback)", c.playerPreview, v -> c.playerPreview = v));

        addRenderableWidget(new Slider(left, y0 + step * 5, bw, 20, "UI size", "%", 90, 150, c.uiScale, v -> c.uiScale = v));
        int by = Math.min(this.height - 28, y0 + step * 6);
        addRenderableWidget(Button.builder(Component.literal("Reset to defaults"), b -> {
            PerspectiveConfig.reset();
            this.rebuildWidgets();
        }).bounds(left, by, bw, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> this.onClose())
                .bounds(right, by, bw, 20).build());
    }

    private static CycleButton<Boolean> toggle(int x, int y, int w, String label, boolean value,
                                               java.util.function.Consumer<Boolean> setter) {
        return CycleButton.onOffBuilder(value).create(x, y, w, 20, Component.literal(label),
                (btn, v) -> setter.accept(v));
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }

    @Override
    public void removed() {
        PerspectiveConfig.save();
    }

    private static final class Slider extends AbstractSliderButton {
        private final String label, suffix;
        private final int min, max;
        private final IntConsumer setter;

        Slider(int x, int y, int w, int h, String label, String suffix, int min, int max, int value, IntConsumer setter) {
            super(x, y, w, h, Component.empty(), (value - min) / (double) (max - min));
            this.label = label; this.suffix = suffix; this.min = min; this.max = max; this.setter = setter;
            updateMessage();
        }

        private int current() { return min + (int) Math.round(this.value * (max - min)); }

        @Override
        protected void updateMessage() {
            if (label != null) setMessage(Component.literal(label + ": " + current() + suffix));
        }

        @Override
        protected void applyValue() { setter.accept(current()); }
    }
}
