# Contributing

- Target: Minecraft 26.1.2, Fabric, Java 25. Build with `gradle build` (see README).
- Keep mixins minimal, prefer `@WrapMethod`, document every mixin in its class comment.
- Never add renderer-backend code (OpenGL/Vulkan calls, shaders, framebuffers); the mod must stay compatible with Sodium and VulkanMod.
- Test: slot clicks, shift-click, drag-splitting, tooltips, Esc and `E` on inventory + at least one container.
