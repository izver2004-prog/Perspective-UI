# Publishing checklist

## 1. Build and test first
1. Install JDK 25 and Gradle 9.x, then: `gradle wrapper --gradle-version 9.4.1 && ./gradlew build`.
2. Fix any compile error from renamed 26.1.2 methods (the `VERIFY` comments in `src/main/java/com/perspectiveui/mixin` mark the likely spots).
3. `./gradlew runClient`, open: inventory, chest, furnace, anvil, enchanting table, villager. Check slot clicks, shift-click, drag-splitting, tooltips, Esc, `E`.
4. Repeat with Sodium and with VulkanMod installed (pick the 26.1.2 builds from their Modrinth pages).
5. Take real screenshots and use `src/main/resources/assets/perspectiveui/icon.png` (128x128) as the icon.

## 2. GitHub
```bash
cd perspective-ui
git init
git add .
git commit -m "Initial commit: Perspective UI"
git branch -M main
git remote add origin https://github.com/<your-username>/perspective-ui.git
git push -u origin main
```
Create the empty `perspective-ui` repository on GitHub first. Then add its URL under `contact` in `fabric.mod.json`.

## 3. Modrinth (manual, do not claim published until it is)
- Create project → name **Perspective UI**, summary: *A client-side Minecraft mod that brings inventory and container screens into perspective with a player preview and smooth animations.*
- Client side: **required**, server side: **unsupported**. License: MIT.
- Categories (suggested): Decoration, Utility.
- Game version **26.1.2**, loader **Fabric**, dependency **Fabric API (required)** – only after step 1 passes.
- Upload `build/libs/perspective-ui-1.0.0+mc26.1.2.jar`, plus screenshots and the icon.
- Version name `1.0.0`, changelog:
  - Initial release
  - Side player preview, tilted floating panel, smooth open/close animations
  - Config: effects, inventory/containers, preview, mouse follow, intensity, speed
- Submit for review; moderation outcome is up to Modrinth.

## Long description (paste into Modrinth)
**Perspective UI** turns the flat inventory into a floating panel. Your character stands on the left in full height, turned slightly toward the menu, while the real, fully working inventory or container floats on the right with a soft tilt, parallax and smooth animations. The world stays visible behind it.

- Real player model with skin, armor and held items
- Gentle mouse-following with inertia, frame-time based animations
- Works with inventory, crafting, chests, barrels, furnaces, anvil, enchanting table, hopper, dispenser, shulker boxes and more
- Everything stays functional: slots, drag & drop, tooltips, scrolling
- Configurable via `/perspectiveui`, saved between launches
- Client-side only; built to stay out of the renderer so it can sit next to Sodium and VulkanMod

Requires Fabric API. Minecraft 26.1.2, Java 25.
