# Perspective UI

A client-side Minecraft mod that brings inventory and container screens into perspective with a player preview and smooth animations.

> **Status:** source code complete, **not yet compiled or tested in-game by the author of this repo snapshot**. Minecraft 26.1.2 changed its GUI API heavily; see [Known limitations](#known-limitations-and-things-to-verify). Do not treat compatibility claims below as confirmed until you have built and run it.

## Features

- Full-height **player preview on the left** (real skin, armor, held items), turned slightly sideways and reacting gently to the mouse. Uses vanilla's own entity-in-GUI renderer – no second entity, no custom GL code.
- The real, working container GUI on the right, with a **tilted, parallax "floating panel" look** (affine approximation of perspective, see limitations).
- Smooth **open / close animations**, scale-in, inertia-based mouse following. All motion is frame-time based, not FPS based.
- Clicks, drag & drop, scrolling and tooltips are mapped through the exact inverse of the rendered transform.
- Supported screens: player inventory, crafting table, chests / large chests / barrels (`ContainerScreen`), shulker box, furnace / smoker / blast furnace, anvil, enchanting table, hopper, dispenser / dropper, brewing stand, grindstone, smithing table, cartography table, stonecutter, loom, villager trading, beacon, crafter, horse inventory. Everything else (including the creative inventory) keeps the vanilla look.
- Settings (persisted in `config/perspective-ui.json`): effects on/off, player inventory vs. containers, player preview, mouse follow, close animation, intensity, animation speed, reset to defaults.

## Requirements

- Minecraft Java Edition **26.1.2**
- Java **25**
- Fabric Loader **0.19.1+**
- Fabric API for 26.1.2
- Client only – not needed on the server.

## Install

Drop `perspective-ui-<version>.jar` into `.minecraft/mods`. Open the settings in-game with the client command `/perspectiveui` (also `/perspectiveui reset` and `/perspectiveui intensity <0-100>`).

## Build

```bash
# Needs JDK 25 and Gradle 9.x (the wrapper jar is not included in this snapshot):
gradle wrapper --gradle-version 9.4.1   # once, generates gradlew + gradle-wrapper.jar
./gradlew build                         # jar in build/libs/
./gradlew runClient                     # dev client
```

Before building, confirm the versions in `gradle.properties` on <https://fabricmc.net/develop/> (Loom, Loader, Fabric API for 26.1.2).

### Build on GitHub (no local setup)

- `.github/workflows/build.yml` builds on every push/PR and uploads the jar as an artifact (Actions → run → Artifacts).
- `.github/workflows/build-from-zip.yml`: upload `perspective-ui.zip` to the repo root; it unpacks and builds it. Run it manually with *commit_sources* to also commit the unpacked files (workflow files are never overwritten).
- `.github/workflows/release.yml`: push a tag like `v1.0.0` to attach the jar to a GitHub Release.

## Compatibility

- **Sodium / VulkanMod:** by design the mod only uses the vanilla GUI pose stack (`GuiGraphicsExtractor.pose()`) and vanilla GUI drawing calls. It contains no OpenGL/Vulkan calls, shaders, framebuffers or mixins into the renderer backend, so it does not depend on which backend renders the frame. Sodium and VulkanMod both list 26.1.2 builds, but **combined testing has not been done yet** – please report results.
- **Other GUI mods:** mixins use MixinExtras `@WrapMethod` (no `@Overwrite`, no HEAD/RETURN cancels except the optional close delay). Mods that draw outside the container panel via their own screen hooks are rendered inside the same transform when they hook the standard screen render path; mods that handle raw mouse events themselves may not be remapped. Disable per screen type in settings if something misbehaves.

## Mixins (all client-side)

| Mixin | Target | Purpose |
|---|---|---|
| `ScreenRenderMixin` | `Screen#extractRenderStateWithTooltipAndSubtitles`, `#extractBackground` | Wrap the full screen draw in the panel transform; keep dim/blur background full-screen |
| `ContainerInputMixin` | mouse methods + `onClose` of container screens | Inverse-map mouse input; delay close for the closing animation |
| `InventoryScreenMixin` | `InventoryScreen#extractEntityInInventoryFollowsMouse` | Hide vanilla's small player while the large preview is shown |
| `AbstractContainerScreenAccessor` | `AbstractContainerScreen` | Read panel position/size |

All injectors use `require = 0` (except the accessor): if a method name differs in your exact game version, the mod falls back to vanilla visuals instead of crashing.

## Known limitations and things to verify

- **No true perspective.** The 26.1 GUI matrix is a 2D affine `Matrix3x2fStack`; real projective warping would need a custom render target/shader, which risks conflicts with Sodium, VulkanMod and other GUI mods. The tilt is an affine approximation (squeeze, shear, parallax).
- No alpha fade (the GUI pose has no alpha); open/close uses scale + slide.
- Opening the recipe book hides the side preview and the layout shift while it is open.
- Vanilla menu background blur still applies; set *Options → Accessibility/Video → Menu Background Blur* to 0 for a crisper world behind the panel.
- Method names marked `VERIFY` in the mixins were derived from the 1.21.x → 26.1 renames and documentation, not from decompiled 26.1.2 sources.
- Creative inventory and unknown modded screens are intentionally left vanilla.
- Screenshots and a final tested JAR are not included.

## License

MIT, see [LICENSE](LICENSE).
